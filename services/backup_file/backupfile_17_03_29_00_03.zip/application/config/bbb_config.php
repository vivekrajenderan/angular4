<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

// ------------------------------------------------------------------------
// BBB (BigBlueButton Wrapper Class)
// ------------------------------------------------------------------------
http://test-install.blindsidenetworks.com/bigbluebutton/api
$config['bbb_server_domain'] = 'http://test-install.blindsidenetworks.com'; // Domain of hosted BBB Server (eg. localhost)
$config['bbb_security_salt'] = '8cd8ef52e8e101574e400365b55e11a6'; // Security Salt
$config['bbb_max_participants'] = 10; // Max Participants

?>