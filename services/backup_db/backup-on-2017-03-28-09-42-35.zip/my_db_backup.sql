#
# TABLE STRUCTURE FOR: category_mst
#

DROP TABLE IF EXISTS category_mst;

CREATE TABLE `category_mst` (
  `pk_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(100) NOT NULL,
  `standing` enum('1','0') NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO category_mst (`pk_cat_id`, `cate_name`, `standing`, `created_on`) VALUES (1, 'sdafsaf', '1', '2016-08-09 10:27:32');
INSERT INTO category_mst (`pk_cat_id`, `cate_name`, `standing`, `created_on`) VALUES (2, 'Kids', '0', '2016-08-09 10:12:37');
INSERT INTO category_mst (`pk_cat_id`, `cate_name`, `standing`, `created_on`) VALUES (4, 'sgsgsgs', '1', '2016-08-09 10:28:11');


#
# TABLE STRUCTURE FOR: channel_mst
#

DROP TABLE IF EXISTS channel_mst;

CREATE TABLE `channel_mst` (
  `pk_ch_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_cat_id` int(11) NOT NULL,
  `channel_name` varchar(100) NOT NULL,
  `channel_logo` text NOT NULL,
  `channel_no` varchar(100) NOT NULL,
  `channel_url` text NOT NULL,
  `standing` enum('1','0') NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime NOT NULL,
  PRIMARY KEY (`pk_ch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO channel_mst (`pk_ch_id`, `fk_cat_id`, `channel_name`, `channel_logo`, `channel_no`, `channel_url`, `standing`, `created_on`, `updated_on`) VALUES (1, 2, 'pogo', '1470717431-channel_logo.jpg', 'pg-001', 'http://www.pogo.com', '1', '2016-08-09 10:07:11', '0000-00-00 00:00:00');
INSERT INTO channel_mst (`pk_ch_id`, `fk_cat_id`, `channel_name`, `channel_logo`, `channel_no`, `channel_url`, `standing`, `created_on`, `updated_on`) VALUES (2, 2, 'chutt tv', '1470717635-channel_logo.gif', 'chu', 'http://www.chuttitv.com', '1', '2016-08-09 10:10:35', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: cust_mst
#

DROP TABLE IF EXISTS cust_mst;

CREATE TABLE `cust_mst` (
  `pk_cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(64) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `emailid` varchar(64) NOT NULL,
  `mobileno` bigint(20) NOT NULL,
  `vc_number` varchar(100) NOT NULL,
  `standing` enum('1','0') NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_cust_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO cust_mst (`pk_cust_id`, `fname`, `lname`, `emailid`, `mobileno`, `vc_number`, `standing`, `created_on`) VALUES (1, 'vivek', 'raj', 'vivek@gmail.com', 5465555555, 'VC-001', '0', '2016-08-09 09:56:18');


#
# TABLE STRUCTURE FOR: user_mst
#

DROP TABLE IF EXISTS user_mst;

CREATE TABLE `user_mst` (
  `pk_uid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(64) NOT NULL,
  `lname` varchar(64) NOT NULL,
  `emailid` varchar(64) NOT NULL,
  `secret_pass` text NOT NULL,
  `mobileno` bigint(20) NOT NULL,
  `standing` enum('1','0') NOT NULL DEFAULT '1',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pk_uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO user_mst (`pk_uid`, `fname`, `lname`, `emailid`, `secret_pass`, `mobileno`, `standing`, `created_on`) VALUES (1, 'admin', 'app', 'admin@aadhar.com', 'Oh/GuheM8lgeNvOQe8u4Og==', 9865656656, '1', '2016-08-08 13:08:50');


